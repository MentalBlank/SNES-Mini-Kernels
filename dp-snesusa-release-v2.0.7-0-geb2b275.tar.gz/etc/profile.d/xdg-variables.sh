XDG_DATA_HOME=/var/lib/clover/profiles/0/
XDG_CONFIG_HOME=/var/lib/clover/config/
XDG_CACHE_HOME=/var/cache/clover/
XDG_DATA_DIRS=/usr/share:/usr/local/share/
XDG_CONFIG_DIRS=/etc
XDG_RUNTIME_DIR=/run
